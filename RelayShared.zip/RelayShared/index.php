<?php
	
	/*
		Read the content of a Json file and write a Json after posting some data
		by L.Moutard
		This example code is in the public domain :-)
		modified 05 mars 2017
	*/
	
	// Fonction de manipulation Json
	include("JSON.php");
	// Future-friendly json_encode
	if( !function_exists('json_encode') ) {
		function json_encode($data) {
			$json = new Services_JSON();
			return( $json->encode($data) );
		}
	}
	// Future-friendly json_decode
	if( !function_exists('json_decode') ) {
		function json_decode($data) {
			$json = new Services_JSON();
			return( $json->decode($data) );
		}
	}
	// Future-friendly file_put_contents
	if (!function_exists('file_put_contents')) {
		function file_put_contents($filename, $data) {
			$f = @fopen($filename, 'w');
			if (!$f) {
				return false;
				} else {
				$bytes = fwrite($f, $data);
				fclose($f);
				return $bytes;
			}
		}
	}
	// Fin de section Fonction de manipulation Json
	
	// Ecriture dans le data.json
	
	$file = "data.json";
	$textVar = file_get_contents($file);
	// print_r($textVar);
	$myJson = (array) json_decode($textVar);
	
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		
		// var_dump($_POST);
		// echo("<br>");

		if (!empty($_POST["formId"]) && $_POST["formId"] == 2) {
			if (!empty($_POST["equipement1"])) {
				$myJson["equipement1"] = $_POST["equipement1"];
				}else{
				$myJson["equipement1"] = "off";
			}
		}
		if (!empty($_POST["formId"]) && $_POST["formId"] == 3) {
			if (!empty($_POST["equipement2"]) && $_POST["formId"] == 3) {
				$myJson["equipement2"] = $_POST["equipement2"];
				}else{
				$myJson["equipement2"] = "off";
			}
			if (!empty($_POST["equipement3"]) && $_POST["formId"] == 3) {
				$myJson["equipement3"] = $_POST["equipement3"];
				}else{
				$myJson["equipement3"] = "off";
			}
		}
		
		$textVar = json_encode($myJson);
		file_put_contents($file, $textVar);
		$soumission = "ok";
		// print_r($textVar);
		}
	
	
	
	?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		
		<!-- Basic Page Needs
		–––––––––––––––––––––––––––––––––––––––––––––––––– -->
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta charset="utf-8">
		<title>RelayWeb</title>
		<meta name="description" content="Driver for connected electrical outlet">
		<meta name="author" content="Laurent Moutard">
		<meta http-equiv='cache-control' content='no-store'>
		<meta http-equiv='expires' content='0'>
		<meta http-equiv='pragma' content='no-store'>
		<!-- Mobile Specific Metas
		–––––––––––––––––––––––––––––––––––––––––––––––––– -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- FONT
		–––––––––––––––––––––––––––––––––––––––––––––––––– -->
		<link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">
		
		<!-- CSS
		–––––––––––––––––––––––––––––––––––––––––––––––––– -->
		<link rel="stylesheet" href="css/normalize.css">
		<link rel="stylesheet" href="css/skeleton.css">
		<link rel="stylesheet" href="css/on-off-switch.css">
		<style>
			.container{
			border-radius: 4px;
			border: 1px solid #bbb;
			padding: 10px;
			}
			
			
		</style>
		
		<script type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
		<script>
			
			//Récupération du dataset.json
			
			$(document).ready(function(){
				getFromElectricDriver();
				var refreshId = setInterval("getFromElectricDriver()", 2000);
				$("#sw_equipement1").click(function(){
					var checkBoxes = $("input[name=equipement1");	
					checkBoxes.prop("checked", !checkBoxes.prop("checked"));
					if($(this).attr("src") == "images/switch_on.jpg"){
						$(this).attr("src", "images/switch_off.jpg");
						}else{
						$(this).attr("src", "images/switch_on.jpg");
					}
					$("#HomeForm2").submit();
				});
				$("#sw_equipement2").click(function(){
					var checkBoxes = $("input[name=equipement2");	
					checkBoxes.prop("checked", !checkBoxes.prop("checked"));
					if($(this).attr("src") == "images/switch_on.jpg"){
						$(this).attr("src", "images/switch_off.jpg");
						}else{
						$(this).attr("src", "images/switch_on.jpg");
					}
					$("#HomeForm3").submit();
				});
				$("#sw_equipement3").click(function(){
					var checkBoxes = $("input[name=equipement3");	
					checkBoxes.prop("checked", !checkBoxes.prop("checked"));
					if($(this).attr("src") == "images/switch_on.jpg"){
						$(this).attr("src", "images/switch_off.jpg");
						}else{
						$(this).attr("src", "images/switch_on.jpg");
					}
					$("#HomeForm3").submit();
				});
			}); 
			
			function getFromElectricDriver(){
				$("#DateModified").text(Date());
				$.getJSON('dataset.json', function(data) {
					$.each( data, function( key, val ) {
						console.log("Key: " + key + " Val : " + val);
						if (key == "equipement1Set"){
							$("#equipement1Set").attr("src", "images/led_"+val+".jpg");
						}
						if (key == "equipement2Set"){
							$("#equipement2Set").attr("src", "images/led_"+val+".jpg");
						}
						if (key == "equipement3Set"){
							$("#equipement3Set").attr("src", "images/led_"+val+".jpg");
						}
					});
				});
			}
			
		</script>
	</head>
	<body onunload="">
		
		<!-- Primary Page Layout
		–––––––––––––––––––––––––––––––––––––––––––––––––– -->
			<div class="container">
				<div class="row">
					<div class="one column">
					</div>
					<div class="ten column">
						<h4 style="margin-bottom: 0.1rem;color:#FF0000">RelayWeb</h4>
						<div id = "DateModified" style="display:inline;"></div>
					</div>
					<div class="one column">
					</div>
				</div>

			</div>
			<input id="formId" name="formId" type="hidden" value="1">
		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST" id="HomeForm2" style="display:inline;">
			<div class="container">
				<div class="row">
					<div class="three columns">
						<label for="equipement1">equipement1</label>
						<img class="fit-picture" src="images/switch_<?php echo ($myJson["equipement1"]);?>.jpg" id="sw_equipement1">
						<input type="checkbox" id="equipement1" name="equipement1" <?php if ($myJson["equipement1"] == "on") echo "checked";?>>
					</div>
					<div class="three columns">
						Etat<br/>
						<img src="images/led_off.jpg" id="equipement1Set">
					</div>
				</div>
			</div>
			<input id="formId" name="formId" type="hidden" value="2">
		</form>
		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST" id="HomeForm3" style="display:inline;">
			<div class="container">
				<div class="row">
					<h4>Prise double</h4>
				</div>
				<div class="row">
					<div class="three columns">
						<label for="equipement2">equipement2</label>
						<img class="fit-picture" src="images/switch_<?php echo ($myJson["equipement2"]);?>.jpg" id="sw_equipement2">
						<input type="checkbox" id="equipement2" name="equipement2" <?php if ($myJson["equipement2"] == "on") echo "checked";?>>
					</div>
					<div class="three columns">
						Etat<br/>
						<img src="images/led_off.jpg" id="equipement2Set">
					</div>
				</div>
				<div class="row">
					<div class="three columns">
						<label for="equipement3">equipement3
							</label>
						<img class="fit-picture" src="images/switch_<?php echo ($myJson["equipement3"]);?>.jpg" id="sw_equipement3">
						<input type="checkbox" id="equipement3" name="equipement3" <?php if ($myJson["equipement3"] == "on") echo "checked";?>>
					</div>
					<div class="three columns">
						Etat<br/>
						<img src="images/led_off.jpg" id="equipement3Set">
					</div>
				</div>
			</div>
			<input id="formId" name="formId" type="hidden" value="3">
		</form>
		<!-- Always wrap checkbox and radio inputs in a label and use a <span class="label-body"> inside of it -->
		
		<!-- End Document
		–––––––––––––––––––––––––––––––––––––––––––––––––– -->
	</body>
</html>
