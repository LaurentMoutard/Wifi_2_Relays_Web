<?php
// Fonction de manipulation Json
include("JSON.php");

if (!function_exists('file_put_contents')) {
    function file_put_contents($filename, $data) {
        $f = @fopen($filename, 'w');
        if (!$f) {
            return false;
        } else {
            $bytes = fwrite($f, $data);
            fclose($f);
            return $bytes;
        }
    }
}
// if( !function_exists('get_file_contents') ) {
	// function get_file_contents($filename)
	// /* Returns the contents of file name passed
	// */
	// {
	// $fhandle = fopen($filename, "r");
	// $fcontents = fread($fhandle, filesize($filename));
	// fclose($fhandle);
	// return $fcontents;
	// }
// }

$textVar = json_decode(file_get_contents("php://input"), TRUE);

$file = "dataset.json";
$json = json_decode(file_get_contents($file),TRUE);
// var_dump($json);

foreach($textVar as $key => $value) {
    $json[$key] = $value;
//    file_put_contents("essai.json",  $json[$key]);
}
file_put_contents($file, json_encode($json));
?>
